package controller;

import form.PermissionForm;
import server.Server;
import form.Form;

public class Controller {
    private Server server;

    public Controller() {
        this.server = new Server();
    }

	public Form process(String userId, String userPass, String code) {
        Form form = null;
        PermissionForm permissionForm = server.getResource(code);
        
        if (permissionForm != null) {
            System.out.println("Resource retrieve successfully");
        } else {
            System.out.println("Failed to retrieve resource with code: " + code);
        }

        permissionForm.fill(userId, userPass);

        int accessCode = server.getAuthorizationCode(permissionForm);
        if (accessCode != -1) {
            form = server.getContentForm(accessCode);
        } else {
            form = server.getNoAccessForm();
        }

        return form;
	}
    
}
