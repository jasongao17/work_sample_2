package form;

public class ContentForm extends Form  {
    
}
