package form;

public class NoAccessForm extends Form {
    
}
