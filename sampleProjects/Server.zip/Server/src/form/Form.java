package form;

public abstract class Form {
    public String toString() {
        return "";
    }
}
