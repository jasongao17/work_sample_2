package form;

public class PermissionForm extends Form {
    private String userId;
    private String pass;

	public void fill(String userId, String userPass) {
        this.userId = userId;
        this.pass = userPass;
    }
    
    public String getId() {
        return this.userId;
    }

    public String getPass() {
        return this.pass;
    }
    
}
