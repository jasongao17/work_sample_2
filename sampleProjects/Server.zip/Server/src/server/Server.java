package server;

import form.PermissionForm;
import service.authentication.AuthorizationService;
import service.content.ContentService;
import application.Application;
import form.ContentForm;
import form.NoAccessForm;

public class Server {
	private Application app;
	private AuthorizationService authService = null;
	private ContentService contentService = null;

	public Server() {
		this.app = new Application();
	}

	public PermissionForm getResource(String code) {
		authService = app.requestAccess(code);
		return authService.authorize(code);
	}

	public int getPermission(PermissionForm form, String userId, String userPass) {
		return 0;
	}

	public int getAuthorizationCode(PermissionForm form) {
		return authService.process(form);
	}

	public ContentForm getContentForm(int accessCode) {
		return app.getContent(accessCode);
	}

	public NoAccessForm getNoAccessForm() {
		return app.getNoAccess();
	}
    
}
