package application;

import form.ContentForm;
import form.NoAccessForm;
import service.authentication.AuthorizationService;
import service.content.ContentService;

public class Application {

	public AuthorizationService requestAccess(String code) {
		return new AuthorizationService();
	}

	public String getAccessToken(int accessCode) {
        AuthorizationService service = new AuthorizationService();
        service.getToken(accessCode);
		return null;
	}

	public ContentForm getContent(int accessCode) {
        AuthorizationService service = new AuthorizationService();
        String token = service.getToken(accessCode);
		return ContentService.getSecureResource(token);
	}

	public NoAccessForm getNoAccess() {
		return new NoAccessForm();
	}
    
}
