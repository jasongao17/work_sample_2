import controller.Controller;
import form.Form;

public class Main {
    private static Controller controller = new Controller();

    public static void main(String[] args) {
        Form form = controller.process(args[0], args[1], args[2]);

        System.out.println("Resource recieved! : " + form);
    }
    
}