package service.content;

import form.ContentForm;
import service.Service;

public class ContentService extends Service {
    public static ContentForm getSecureResource(String token) {
        return new ContentForm();
    }
}
