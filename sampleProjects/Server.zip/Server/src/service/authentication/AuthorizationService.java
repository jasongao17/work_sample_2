package service.authentication;

import form.PermissionForm;
import service.Service;

public class AuthorizationService extends Service {
    private String AUTH_CODE = "120";

	public PermissionForm authorize(String code) {
        if (AUTH_CODE.equals(code)) {
            return new PermissionForm();
        }
		return null;
    }
    
    public int process(PermissionForm form) {
        return 0;
    }

	public String getToken(int accessCode) {
		return null;
	}
    
}
