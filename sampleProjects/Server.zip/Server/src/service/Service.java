package service;

public abstract class Service {

    public int healthCheck() {
        return 200;
    }
}
