package libs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AlternativeTokenizer implements Tokenizer {

    public static Tokenizer createAlternativeTokenizer(String filename, List<String> fixedLiteralsList, List<Character> separatorTokens, List<Character> separatorNonTokens, List<String> customTokenPatterns)
    {
        return new AlternativeTokenizer(filename, fixedLiteralsList, separatorTokens, separatorNonTokens, customTokenPatterns);
    }

    private String inputProgram;
    private List<String> fixedLiterals;
    private List<Character> allSeparators;
    private List<Character> separatorNonTokens;
    private List<String> customTokenPatterns;
    private String[] tokens;
    private int currentToken = 0;

    private AlternativeTokenizer(String filename, List<String> fixedLiterals, List<Character> allSeparators, List<Character> separatorNonTokens, List<String> customTokenPatterns){
        this.fixedLiterals = fixedLiterals;
        this.allSeparators = allSeparators;
        this.separatorNonTokens = separatorNonTokens;
        this.customTokenPatterns = customTokenPatterns;
        try {
            inputProgram = Files.readString(Paths.get(filename));
        } catch (IOException e) {
            System.out.println("Didn't find file");
            System.exit(0);
        }
        tokenize();
    }

    //modifies: this.tokens
    //effects: will result in a list of tokens (sitting at this.tokens) that has no spaces around tokens.
    private void tokenize () {
        assert(inputProgram != null && inputProgram.length() > 0); // no empty programs allowed! Better to handle this with a decent error message, though.

        // find all of the separator positions:
        TreeSet<Integer> tokenPositions = new TreeSet<>(); // TreeSet inserts in sorted order
        TreeSet<Integer> nonTokenSeparatorPositions = new TreeSet<>(); // track which "tokens" should actually be dropped

        for(Character c : allSeparators) {
            int index = inputProgram.indexOf(c);

            while(index != -1) { // while we find an occurrence
                tokenPositions.add(index); // accumulate them all for now (even any non-token separators)
                if(separatorNonTokens.contains(c)) { // but remember where we found the non-token separators; we'll drop them at the end
                    nonTokenSeparatorPositions.add(index);
                }
                index = inputProgram.indexOf(c, index + 1); // find next occurrence of this separator
            }
        }

        List<Range> toProcess = new ArrayList<>(); ; // indices between which there's a substring (start up to but not including end) still to process
        int from = 0; // next range to look at starts from this position

        for(int i : tokenPositions) {
            toProcess.add(new Range(from,i));
            from = i + 1; // skip the separator; look from next character onwards
        }
        if(from < inputProgram.length()) { // still some program left after the last separator
            toProcess.add(new Range(from,inputProgram.length()));
        }

        while(!toProcess.isEmpty()) { // step through each range and process it
            Range current = toProcess.get(0); // always deal with the first range
            int start = current.start;
            int end = current.end;
            boolean madeChange = false;
            String processing = inputProgram.substring(start, end);
            for(String f : fixedLiterals) {
                if(processing.startsWith(f)) {
                    tokenPositions.add(start); // we found a token here!
                    madeChange = true;
                    if(end - start > f.length()) { // some part of the range is left over
                        current.start += f.length(); // move the start of this range to exclude the newly-found token
                    } else {
                        toProcess.remove(0); // kill this range - we've dealt with it completely!
                    }
                    // in both cases, we want to iterate the outer loop again *without* changing i...
                    break;
                }
            }
            if(madeChange) {
                continue; // if we already made a change, iterate the outer loop again
            }
            for(String custom : customTokenPatterns) {
                Pattern p = Pattern.compile(custom);
                Matcher m = p.matcher(processing);
                if(m.lookingAt()) { // strange name, but this means: the start of the string matches the pattern
                    tokenPositions.add(start);
                    madeChange = true;
                    if(end - start > m.end()) { // some part of the range is left over
                        current.start += m.end(); // move the start of this range to exclude the newly-found token
                    } else {
                        toProcess.remove(0); // kill this range - we've dealt with it completely!
                    }
                    // in both cases, we want to iterate the outer loop again *without* changing i...
                    break;
                }
            }
            if(!madeChange) {
                throw new RuntimeException("Couldn't tokenize the substring: " + processing);
            }
        }
        tokens = new String[tokenPositions.size() - nonTokenSeparatorPositions.size()]; // we'll get this many final tokens
        tokenPositions.add(inputProgram.length()); // makes splitting logic simpler; we have the start and end of each token
        int tokenIndex = 0;
        int lastPos = 0; // interesting: dropping this generates a might-not-have been initialised warning.
        for(int p: tokenPositions) {
            if(p > 0) { // skip first; we want the ranges between pairs of tokenPositions
                if(!nonTokenSeparatorPositions.contains(lastPos)) { // skip this "chunk" if it's a match of a non-token separator
                    tokens[tokenIndex] = inputProgram.substring(lastPos, p);
                    tokenIndex++;
                }
            }
            lastPos = p;
        }
        System.out.println("FINAL TOKENS: "+ Arrays.asList(tokens)); // FOR GRADING: make sure this line gets printed in this format!
    }


    private String checkNext(){
        String token="";
        if (currentToken<tokens.length){
            token = tokens[currentToken];
        }
        else
            token="NO_MORE_TOKENS";
        return token;
    }

    @Override
    public String getNext(){
        String token="";
        if (currentToken<tokens.length){
            token = tokens[currentToken];
            currentToken++;
        }
        else
            token="NULLTOKEN";
        return token;
    }


    @Override
    public boolean checkToken(String regexp){
        String s = checkNext();
        System.out.println("comparing: |"+s+"|  to  |"+regexp+"|");
        return (s.matches(regexp));
    }


    @Override
    public String getAndCheckNext(String regexp){
        String s = getNext();
        if (!s.matches(regexp)) {
            throw new RuntimeException("Unexpected next token for Parsing! Expected something matching: " + regexp + " but got: " + s);
        }
        System.out.println("matched: "+s+"  to  "+regexp);
        return s;
    }

    @Override
    public boolean moreTokens(){
        return currentToken<tokens.length;
    }

}
