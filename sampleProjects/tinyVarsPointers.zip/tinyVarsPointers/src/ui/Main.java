package ui;

import ast.Program;
import ast.tinyVarsEvaluator;
import ast.tinyVarsParser;
import libs.AlternativeTokenizer;
import libs.Tokenizer;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        List<String> fixedLiterals = Arrays.asList("set", "print", "new", ",", ";", "&", "*");
        List<Character> allSeparators = Arrays.asList(' ', '\n');
        List<Character> separatorNonTokens = allSeparators;
        List<String> userDefinedLiterals = Arrays.asList(tinyVarsParser.NAME, tinyVarsParser.CONST);

        Tokenizer tokenizer = AlternativeTokenizer.createAlternativeTokenizer("input.tvar", fixedLiterals, allSeparators, separatorNonTokens, userDefinedLiterals);
        System.out.println("Done tokenizing");

        tinyVarsParser p = tinyVarsParser.getParser(tokenizer);
        Program program = p.parseProgram();
        System.out.println("Done parsing");

        tinyVarsEvaluator e = new tinyVarsEvaluator("output.txt");
        program.accept(e);
        e.closeFile();
        System.out.println("completed successfully");
        System.out.println("Final Environment: " + e.getEnvironment());
        System.out.println("Final Memory: " + e.getMemory());
    }

}
