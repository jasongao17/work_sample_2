package ast;

public class DereferenceExp extends Exp {
    public DereferenceExp(Exp toDereference) {
        this.expToDereference = toDereference;
    }

    private Exp expToDereference;

    public Exp getExpToDereference() {
        return expToDereference;
    }

    @Override
    public <T> T accept(tinyVarsVisitor<T> v) {
        return v.visit(this);
    }
}
