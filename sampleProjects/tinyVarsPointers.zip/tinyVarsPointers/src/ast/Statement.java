package ast;

import libs.Node;

public abstract class Statement extends Node {
}
