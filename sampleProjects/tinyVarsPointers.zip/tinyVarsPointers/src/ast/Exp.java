package ast;

import libs.Node;
import libs.Tokenizer;

public abstract class Exp extends Node {
  // all functionality is in the sub-classes!
}
