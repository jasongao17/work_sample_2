package ast;

public class AddressOfVar extends Exp {
    public AddressOfVar(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    private String name; // you could also have a Name-typed field here, but we will never evaluate the variable occurrence directly, so e.g. its evaluate functionality isn't helpful.

    @Override
    public <T> T accept(tinyVarsVisitor<T> v) {
        return v.visit(this);
    }
}
