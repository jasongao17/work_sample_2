package ast;

import libs.Tokenizer;

import java.util.ArrayList;
import java.util.List;

public class tinyVarsParser {
    public static final String NAME = "[A-Za-z][A-Za-z0-9]*";
    public static final String CONST = "[0-9]+"; // integer constants

    private final Tokenizer tokenizer;

    public static tinyVarsParser getParser(Tokenizer tokenizer) {
        return new tinyVarsParser(tokenizer);
    }

    private tinyVarsParser(Tokenizer tokenizer) {
        this.tokenizer = tokenizer;
    }

    //PROGRAM ::= STMT*
    public Program parseProgram() {
        List<Statement> statements = new ArrayList<>();
        while (tokenizer.moreTokens()) {
          statements.add(parseStatement());
        }
        return new Program(statements);
    }

    // STMT    ::= DECLARE | ASSIGN | PRINT | …
    private Statement parseStatement() {
        if (tokenizer.checkToken("set")) {
            return parseSet();
        }
        else if (tokenizer.checkToken("new")){
            return parseDec();
        }
        else if (tokenizer.checkToken("print")){
            return parsePrint();
        }
        else {
            throw new RuntimeException("Unknown statement:" + tokenizer.getNext());
        }
    }

    // DECLARE ::= “new” NAME “;”
    private Dec parseDec() {
        tokenizer.getAndCheckNext("new");
        String name = tokenizer.getAndCheckNext(NAME);
        tokenizer.getAndCheckNext(";");
        return new Dec(name);
    }

    // Note - you might also choose to split this into several methods where we branch (at the ? in the new rule):
    //ASSIGN ::= “set” (“*”)? NAME “,” EXP “;”
    private Set parseSet() {
        boolean LHSDereferenced = false; // is this the new set *x, ... form?
        tokenizer.getAndCheckNext("set");
        if(tokenizer.checkToken("\\*")) {
            LHSDereferenced = true;
            tokenizer.getNext(); // consume the "*" and carry on
        }
        String name = tokenizer.getAndCheckNext(NAME);
        tokenizer.getAndCheckNext(",");
        Exp exp = parseExp();
        tokenizer.getAndCheckNext(";");
        if(LHSDereferenced) { // choose which type of AST node to build
            return new SetDereferenced(name, exp);
        } else {
            return new Set(name, exp);
        }
    }


    // Print ::= “print” EXP “;”
    private Print parsePrint() {
        tokenizer.getAndCheckNext("print");
        Exp exp = parseExp();
        tokenizer.getAndCheckNext(";");
        return new Print(exp);
    }

    // EXP ::= USE | CONST | … // we assume just USE and CONST here
    // USE ::= NAME  // we'll inline the (simple) rule for USE!
    private Exp parseExp() {
        // we need to choose between two user-defined tokens, here!
        // The simple parsing strategy doesn't quite handle this, but
        // since CONST and NAME can be distinguished from each other,
        // we can just write out the if-conditions:
        if (tokenizer.checkToken(NAME)) { // we could also write a parseName() method and just call it
            return new Name(tokenizer.getNext());
        }
        else if (tokenizer.checkToken(CONST)){ // we could also write a parseNumber() method and just call it
            return new Number(Integer.parseInt(tokenizer.getNext()));
        }
        else if (tokenizer.checkToken("&")) { // we could also write a parseAddressOfVar() method and just call it
            tokenizer.getNext(); // we know what it is; discard it
            String name = tokenizer.getAndCheckNext(NAME); // what follows must be a NAME!
            return new AddressOfVar(name);
        } else if (tokenizer.checkToken("\\*")){ // we could also write a parseAddressOfVar() method and just call it
            tokenizer.getNext(); // we know what it is; discard it
            Exp e = parseExp(); // parse the expression following the "*"
            return new DereferenceExp(e);
        }
        else {
            throw new RuntimeException("Unknown expression:" + tokenizer.getNext());
        }
    }
}
