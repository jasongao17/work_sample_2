package ast;

public class SetDereferenced extends Set {
    public SetDereferenced(String name, Exp exp) {
        super(name, exp);
    }

    @Override // don't forget to do this if you override concrete AST classes, or your visitors will visit the wrong case!
    public <T> T accept(tinyVarsVisitor<T> v) {
        return v.visit(this);
    }
}
