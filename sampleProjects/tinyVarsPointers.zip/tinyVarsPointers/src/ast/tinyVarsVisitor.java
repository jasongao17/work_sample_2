package ast;

public interface tinyVarsVisitor<T> {
    // Recall: one visit method per concrete AST node subclass
    T visit(Program p);
    T visit(Dec d);
    T visit(Set s);
    T visit(Print p);
    T visit(Name n);
    T visit(Number n);
    T visit(AddressOfVar a);
    T visit(DereferenceExp d);
    T visit(SetDereferenced s);
}
