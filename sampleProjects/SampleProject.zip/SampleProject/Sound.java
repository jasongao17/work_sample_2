

public class Sound {

	public void soundFunction() {
	}

}
