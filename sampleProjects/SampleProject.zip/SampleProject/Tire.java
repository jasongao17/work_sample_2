public class Tire {

	public void engage() {
        grip();
        heat();
	}

    private void heat() {
    }

    private void grip() {
    }

}
