public class Brake {
    Tire tire = new Tire();

	public void stop() {
        tire.engage();
	}
    
}
