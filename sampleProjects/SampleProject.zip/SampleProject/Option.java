

public class Option {

	public static void optionalFunction() {
	}

}
