import java.util.ArrayList;
import java.util.List;

public class Ferrari {
    private Car car;
    private List<String> testList = new ArrayList<String>();

	public Ferrari() {
        car = new Car();
	}

	public void foo() {
        int f = 10;
        car.carFunction(f);
        // do something
        f += 10;
        this.ferrariFunction();
        Radio radio = new Radio();
        radio.radioFunction();

        for (String s : testList) {
            car.carFunction3();
        }

        if (f >= 20) {
            Option.optionalFunction();
        }

        if (f < 20) {
            car.hp(30);
        } else {
            car.test("test");
        }

        foo();
	}

    private void ferrariFunction() {

    }
}